# FNF Bot Spammer

A simple Python script that spams keys and holds arrow keys (← ↑ ↓ →) for rhythm games like Friday Night Funkin’.

---

## Requirements
- Python 3.8 or newer
- Install the required library:
    pip install pynput

---

## How to Run
1. Download `BOT_FNF.py`
2. Place `BOT_FNF.py` and this `README.txt` in the same folder.
3. Open a terminal or command prompt in that folder.
4. Run the script:
    python BOT_FNF.py
5. When the program starts:
   - Enter the starting CPS (clicks per second). Default = 10
   - Enter the starting keys to spam. Default = z x , .

---

## Hotkeys
- F9  → Start spam + hold arrow keys
- F8  → Stop spam + release arrow keys
- F1  → Change spam keys (type new keys in console)
- F10 → Change CPS (type new CPS in console)
- Esc → Exit program

---

## Features
- Spam any keys you choose at adjustable CPS
- Works well with in-game "Safe Frames" set to 2  
  *Example:* Safe Frames = 2 → you can hit notes up to 2 frames early or late (~±33ms at 60 FPS)
- Hold arrow keys while spamming
- Change spam keys anytime
- Change CPS anytime
- Global hotkeys (works in background)

---

## In-Game Setup
To match the script with your game settings:

1. Open **Settings** in Friday Night Funkin’.
2. Go to the **Gameplay** tab.
3. Find the option **Safe Frames**.
4. Set it to **2** (recommended).

This ensures the bot’s timing matches the in-game hit window.

---

## Download Info
If you downloaded this project as a ZIP, use the following password to extract:

Password: **DovkilYT2025**

ZIP Name: **BOT_FNF_By_DovkilYT.zip**

---

## Credits
- Script made with ❤️  
- Special thanks to **DovkilYT** (YouTube)

---

## Disclaimer
This script is for educational purposes only.  
Using it in online games may be considered cheating.  
Use responsibly.
